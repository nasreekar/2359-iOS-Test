//: Playground - noun: a place where people can play

import UIKit

//Question 1: Unique Array
print("Unique Array Question");
print("");

var array = [1,1,3,3,3,5,5,5,9,9,9,9];
var currVal = 0;
var result: [Int] = [];
var i = 0;

while(i<array.count)
{
    if(array[i] != currVal)
    {
        result.append(array[i]);
        currVal = array[i];
    }
    if(i+1 < array.count && array[i+1]==array[i])
    {
        i = i+2;
    }
    else
    {
        i++;
    }
}
for(var j = 0;j<result.count;j++){
    print(result[j]);
}
print("");
print("***************************");


//Question 2: ATM

print("");
print("ATM Question");
print("");

var amt = 2013;
var num50 = 0;var num10 = 0 ;
var num5 = 0; var num1 = 0;

num50 = amt/50;
amt = amt%50;
num10 = amt/10;
amt = amt%10;
num5 = amt/5;
amt = amt%5;
num1 = amt/1;
amt = amt%1;

print("$50:",num50);
print("$10:",num10);
print("$5:",num5);
print("$1:",num1);

//for(var i = 0; i<num50;i++)
//{
//    print("$50", terminator:",");
//}
//for(var i = 0; i<num10;i++)
//{
//    print("$10", terminator:",");
//}
//for(var i = 0; i<num5;i++)
//{
//    print("$5", terminator:",");
//}
//for(var i = 0; i<num1;i++)
//{
//    print("$1",terminator:",");
//}






